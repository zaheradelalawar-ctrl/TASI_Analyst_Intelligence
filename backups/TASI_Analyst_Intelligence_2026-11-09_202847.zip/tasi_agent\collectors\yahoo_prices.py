"""
Yahoo Finance price collector.

Populates:
  index_prices  - TASI benchmark (multiple tickers tried in order)
  prices        - daily closes for every ticker in recommendations + .SR
  splits        - real stock splits from Yahoo + manual overrides from
                  data/manual_splits.json

Yahoo's ^TASI.SR feed is unreliable (returned 1 day on 2026-11-09). We try
^TASI.SR, TASI.SR, and the KSA ETF proxy in sequence. If all fail, index_prices
remains empty and the performance section explicitly reports that the benchmark
is unavailable rather than silently computing zero benchmark.
"""
from __future__ import annotations

import datetime as dt
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import requests

from .base import Collector

YAHOO_TICKER_TEMPLATE = "{ticker}.SR"

BENCHMARK_TICKERS = [
    ("^TASI.SR", "Tadawul All Share Index (Yahoo)"),
    ("TASI.SR", "Tadawul (alternate Yahoo symbol)"),
    ("KSA", "iShares MSCI Saudi Arabia ETF (US proxy)"),
]

HTTP_HOSTS = ("query2.finance.yahoo.com", "query1.finance.yahoo.com")

MIN_SPLIT_RATIO = 0.5
MAX_SPLIT_RATIO = 10.0


def _is_plausible_split(ratio: float) -> bool:
    return MIN_SPLIT_RATIO <= ratio <= MAX_SPLIT_RATIO


class YahooPriceCollector(Collector):
    name = "yahoo_prices"
    source_type = "yahoo"

    def fetch(self):
        return []

    # ==================================================================
    # yfinance path (preferred)
    # ==================================================================
    def _fetch_via_yfinance(self, yahoo_ticker: str, days: int = 400):
        try:
            import yfinance as yf  # type: ignore
        except ImportError:
            return None, None

        try:
            t = yf.Ticker(yahoo_ticker)
            hist = t.history(period=f"{days}d", auto_adjust=False, actions=True)
            if hist is None or hist.empty:
                return [], []
            series: list[tuple[str, float]] = []
            for idx, close in zip(hist.index, hist["Close"]):
                try:
                    if close != close:
                        continue
                    d = idx.date().isoformat() if hasattr(idx, "date") else str(idx)[:10]
                    series.append((d, float(close)))
                except Exception:
                    continue
            splits: list[tuple[str, float]] = []
            if "Stock Splits" in hist.columns:
                for idx, ratio in hist["Stock Splits"].items():
                    try:
                        r = float(ratio)
                        if r and r > 0 and r != 1.0:
                            d = idx.date().isoformat() if hasattr(idx, "date") else str(idx)[:10]
                            splits.append((d, r))
                    except Exception:
                        continue
            return series, splits
        except Exception as exc:                         # noqa: BLE001
            print(f"    [yf] {yahoo_ticker} error: {exc}")
            return None, None

    # ==================================================================
    # HTTP fallback
    # ==================================================================
    def _fetch_via_http(self, yahoo_ticker: str, days: int = 400):
        params = {
            "period1": int(time.time()) - days * 86400,
            "period2": int(time.time()),
            "interval": "1d",
            "events": "split",
        }
        headers = {
            "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                           "AppleWebKit/537.36 (KHTML, like Gecko) "
                           "Chrome/124.0 Safari/537.36"),
            "Accept": "application/json,text/plain,*/*",
        }
        for host in HTTP_HOSTS:
            url = f"https://{host}/v8/finance/chart/{yahoo_ticker}"
            try:
                r = requests.get(url, params=params, headers=headers, timeout=20)
            except requests.RequestException as exc:
                print(f"    [http] {host} {yahoo_ticker}: {exc}")
                continue
            if r.status_code != 200:
                print(f"    [http] {host} {yahoo_ticker}: HTTP {r.status_code}")
                continue
            if "json" not in (r.headers.get("content-type") or "").lower():
                print(f"    [http] {host} {yahoo_ticker}: non-JSON response")
                continue
            try:
                payload = r.json()
            except ValueError:
                print(f"    [http] {host} {yahoo_ticker}: invalid JSON")
                continue
            result = (payload.get("chart") or {}).get("result") or []
            if not result:
                continue
            ts = result[0].get("timestamp") or []
            closes = (((result[0].get("indicators") or {}).get("quote") or [{}])[0]
                      .get("close")) or []
            series: list[tuple[str, float]] = []
            for stamp, close in zip(ts, closes):
                if close is None:
                    continue
                d = datetime.fromtimestamp(stamp, tz=timezone.utc).date().isoformat()
                series.append((d, float(close)))
            splits: list[tuple[str, float]] = []
            for s in (((result[0].get("events") or {}).get("splits")) or {}).values():
                try:
                    ratio = float(s["numerator"]) / float(s["denominator"])
                    d = dt.datetime.fromtimestamp(s["date"]).date().isoformat()
                    splits.append((d, ratio))
                except Exception:
                    continue
            return series, splits
        return [], []

    # ==================================================================
    def _fetch_series(self, yahoo_ticker: str, days: int = 400):
        series, splits = self._fetch_via_yfinance(yahoo_ticker, days)
        if series is None:
            return self._fetch_via_http(yahoo_ticker, days)
        return series, splits

    # ==================================================================
    def _store_splits(self, conn, ticker: str, splits: list[tuple[str, float]],
                      now: str) -> tuple[int, int]:
        kept = 0
        rejected = 0
        for ex_date, ratio in splits:
            if not _is_plausible_split(ratio):
                rejected += 1
                continue
            conn.execute(
                "INSERT OR REPLACE INTO splits (ticker, ex_date, ratio, source, fetched_at) "
                "VALUES (?,?,?,?,?)",
                (ticker, ex_date, ratio, "yahoo", now),
            )
            kept += 1
        return kept, rejected

    # ==================================================================
    def _load_manual_splits(self, conn, now: str) -> int:
        path = Path(self.cfg["_root"]) / "data" / "manual_splits.json"
        if not path.exists():
            return 0
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:                         # noqa: BLE001
            print(f"  [manual_splits] parse error: {exc}")
            return 0
        count = 0
        for ticker, events in data.items():
            if ticker.startswith("_") or not isinstance(events, list):
                continue
            for ev in events:
                try:
                    ex = str(ev["ex_date"]).strip()
                    ratio = float(ev["ratio"])
                    if not ex or ratio <= 0:
                        continue
                    conn.execute(
                        "INSERT OR REPLACE INTO splits "
                        "(ticker, ex_date, ratio, source, fetched_at) VALUES (?,?,?,?,?)",
                        (ticker, ex, ratio, "manual", now),
                    )
                    count += 1
                except Exception:
                    continue
        conn.commit()
        if count:
            print(f"  [manual_splits] loaded {count} override(s) from {path.name}")
        return count

    # ==================================================================
    def store(self, conn) -> dict:
        stats = {"index_days": 0, "index_source": None,
                 "tickers": 0, "price_days": 0,
                 "splits_kept": 0, "splits_rejected": 0,
                 "manual_splits": 0, "failed": 0}
        now = dt.datetime.now().isoformat(sep=" ", timespec="seconds")

        # ---- benchmark index: try each ticker until one works ------
        print(f"  fetching benchmark (trying {len(BENCHMARK_TICKERS)} tickers)")
        idx_series: list[tuple[str, float]] = []
        chosen = None
        for bticker, blabel in BENCHMARK_TICKERS:
            print(f"    trying {bticker} ({blabel})")
            try:
                series, _ = self._fetch_series(bticker, days=1200)
            except Exception as exc:                     # noqa: BLE001
                print(f"    {bticker}: error {exc}")
                continue
            n = len(series or [])
            if n >= 30:
                print(f"    got {n} days from {bticker}")
                idx_series = series
                chosen = bticker
                break
            print(f"    {bticker}: only {n} days, trying next")

        if chosen:
            for d, close in idx_series:
                conn.execute(
                    "INSERT OR REPLACE INTO index_prices (date, close) VALUES (?,?)",
                    (d, close),
                )
                stats["index_days"] += 1
            conn.commit()
            stats["index_source"] = chosen
            print(f"    {stats['index_days']} index days written from {chosen}")
        else:
            print(f"    [warn] no benchmark ticker worked; "
                  f"performance will report benchmark unavailable")

        # ---- tickers -----------------------------------------------
        tickers = [r[0] for r in conn.execute(
            "SELECT DISTINCT ticker FROM recommendations ORDER BY ticker"
        ).fetchall()]
        print(f"  fetching prices for {len(tickers)} tickers")

        for ticker in tickers:
            yahoo_ticker = YAHOO_TICKER_TEMPLATE.format(ticker=ticker)
            series, splits = self._fetch_series(yahoo_ticker)
            if not series:
                stats["failed"] += 1
                print(f"    {ticker}: NO DATA")
                continue

            for d, close in series:
                conn.execute(
                    "INSERT OR REPLACE INTO prices (ticker, date, close) VALUES (?,?,?)",
                    (ticker, d, close),
                )
                stats["price_days"] += 1

            kept, rejected = self._store_splits(conn, ticker, splits, now)
            stats["splits_kept"] += kept
            stats["splits_rejected"] += rejected
            conn.commit()
            stats["tickers"] += 1

            note = ""
            if kept:
                note += f", {kept} split(s)"
            if rejected:
                note += f", {rejected} rejected"
            print(f"    {ticker}: {len(series)} days{note}")
            time.sleep(0.5)

        # ---- manual overrides --------------------------------------
        stats["manual_splits"] = self._load_manual_splits(conn, now)

        print(f"  done: {stats}")
        return stats