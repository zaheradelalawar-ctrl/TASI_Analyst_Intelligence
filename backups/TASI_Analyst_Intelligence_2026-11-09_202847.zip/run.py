#!/usr/bin/env python3
"""
TASI Analyst Consensus Intelligence Agent - command line entry point.

  python run.py init                    create the database and seed providers
  python run.py demo                    seed clearly-labelled synthetic data
  python run.py collect [--source X]    run a collector and ingest results
  python run.py collect --source prices populate TASI + stock price history
  python run.py report [--date ISO]     build HTML / MD / XLSX reports + open
  python run.py perf                    print analyst performance summary
  python run.py dashboard               launch the Streamlit dashboard
  python run.py doctor                  environment and health check
  python run.py run-all                 daily pipeline (collect + report)

Sources accepted by --source:
  argaam (alias: argaam_pages) | euroland | aljazira | pdf | prices | demo
"""
from __future__ import annotations

import argparse
import datetime as dt
import sys
from pathlib import Path

from tasi_agent import __version__
from tasi_agent.collectors import (aljazira, argaam_pages, demo, euroland_ir,
                                   pdf_inbox, yahoo_prices)
from tasi_agent.config import db_path, load
from tasi_agent.consensus import (STATUS_LABEL, build_consensus,
                                  confirmed_with_dissent, conflicting,
                                  highlighted)
from tasi_agent.db import connect, init_db, log
from tasi_agent.ingest import ingest_items
from tasi_agent.performance import aggregate, evaluate
from tasi_agent.registry import seed_providers
from tasi_agent.report import write_reports


COLLECTOR_CHOICES = ("argaam", "argaam_pages", "euroland", "aljazira",
                     "pdf", "prices", "demo")


# ---------------------------------------------------------------------------
# Collector registry
# ---------------------------------------------------------------------------
def _collector(source: str, cfg: dict, debug: bool = False):
    if source in ("argaam", "argaam_pages"):
        return argaam_pages.ArgaamPagesCollector(cfg, debug=debug)
    if source == "euroland":
        return euroland_ir.EurolandIrCollector(cfg)
    if source == "aljazira":
        return aljazira.AlJaziraCollector(cfg)
    if source == "pdf":
        return pdf_inbox.PdfInboxCollector(cfg)
    if source == "prices":
        return yahoo_prices.YahooPriceCollector(cfg)
    if source == "demo":
        return demo.DemoCollector(cfg)
    raise SystemExit(f"unknown source: {source!r}; choose from {COLLECTOR_CHOICES}")


def _enabled_default_targets(cfg: dict) -> list[str]:
    """When --source is not given, run every enabled collector plus the PDF inbox."""
    targets: list[str] = []
    coll = cfg.get("collectors", {})
    if coll.get("argaam", {}).get("enabled"):
        targets.append("argaam")
    if coll.get("euroland", {}).get("enabled"):
        targets.append("euroland")
    if coll.get("aljazira", {}).get("enabled"):
        targets.append("aljazira")
    if coll.get("pdf_inbox", {}).get("enabled", True):
        targets.append("pdf")
    return targets


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------
def cmd_init(cfg: dict) -> int:
    conn = init_db(db_path(cfg))
    added = seed_providers(conn)
    print(f"Database ready at {db_path(cfg)}")
    print(f"Providers seeded: {added}")
    return 0


def cmd_demo(cfg: dict) -> int:
    conn = init_db(db_path(cfg))
    seed_providers(conn)
    stats = ingest_items(conn, demo.DemoCollector(cfg).fetch(), cfg)
    demo.seed_prices(conn)
    print("Demo seed complete:", stats)
    print("Demo data is synthetic. The report will carry a DEMO banner until it is purged.")
    return 0


def cmd_collect(cfg: dict, source: str | None, debug: bool = False) -> int:
    conn = init_db(db_path(cfg))
    seed_providers(conn)

    targets = [source] if source else _enabled_default_targets(cfg)
    if not targets:
        print("No collectors enabled. Set collectors.<name>.enabled: true in config.yaml, "
              "or pass --source <name>.")
        return 1

    total = {"seen": 0, "inserted": 0, "duplicate": 0,
             "promoted": 0, "rejected": 0, "review": 0}

    for name in targets:
        print(f"\n=== {name} ===")
        try:
            collector = _collector(name, cfg, debug=debug)
            # Price collectors write directly to the database - no RawItem flow.
            store_fn = getattr(collector, "store", None)
            if callable(store_fn):
                store_fn(conn)
                continue

            items = collector.fetch()
        except Exception as exc:                         # noqa: BLE001
            log(conn, f"collect:{name}", f"collector failed: {exc}", level="error")
            print(f"  FAILED: {exc}")
            continue

        print(f"  fetched raw items: {len(items)}")
        if not items:
            continue

        stats = ingest_items(conn, items, cfg)
        for k in total:
            total[k] += stats[k]
        print(f"  ingest stats: {stats}")

    print(f"\nTOTAL: {total}")
    return 0


def cmd_report(cfg: dict, as_of: str | None) -> int:
    """
    Build the report.

    Generates five sections and writes HTML/MD/XLSX to output/.

    Console output summarises each section:
      A · Strong and clean confirmations  (positive >= threshold, no negatives)
      B · Confirmed with dissent           (positive >= threshold, only non-material negatives)
      C · Conflicting opinions             (material dissent)
      D · Single / unconfirmed             (one positive, or no qualifying positive)
      E · Historical performance           (per-firm hit rate vs benchmark)
    """
    conn = init_db(db_path(cfg))
    as_of = as_of or dt.date.today().isoformat()

    results = build_consensus(conn, cfg, as_of)
    section_a = highlighted(results)
    section_b = confirmed_with_dissent(results)
    section_c = conflicting(results)

    # CRITICAL: generate and write all report files. Without this line the
    # console would print results but no file would be written to output/.
    written = write_reports(conn, results, cfg, as_of)

    print(f"\nReport date: {as_of}")
    print(f"Stocks analysed: {len(results)}   "
          f"Clean: {len(section_a)}   "
          f"With dissent: {len(section_b)}   "
          f"Conflicting: {len(section_c)}")

    if section_a:
        print("\nSection A — Strong and clean confirmations")
        for sc in section_a:
            print(f"  [A] {sc.ticker:>4} {sc.company_name or '':<28} "
                  f"{STATUS_LABEL[sc.status]:<32} ({len(sc.positive)} firms)")

    if section_b:
        print("\nSection B — Confirmed with dissent")
        for sc in section_b:
            print(f"  [B] {sc.ticker:>4} {sc.company_name or '':<28} "
                  f"({len(sc.positive)} pos, {len(sc.negative)} neg)")

    if section_c:
        print("\nSection C — Conflicting opinions")
        for sc in section_c:
            print(f"  [C] {sc.ticker:>4} {sc.company_name or '':<28} "
                  f"({len(sc.positive)} pos, {len(sc.neutral)} neu, {len(sc.negative)} neg)")

    for label, path in written.items():
        print(f"  {label.upper():<4} {path}")
    return 0


def cmd_perf(cfg: dict) -> int:
    conn = init_db(db_path(cfg))
    rows = evaluate(conn, cfg)
    if not rows:
        print("No evaluable recommendations yet.")
        print("Run: python run.py collect --source prices  (populates price history)")
        return 0
    agg = aggregate(rows, cfg["performance"]["min_sample_for_publication"])
    print(f"{'Firm':<28}{'N':>5}{'vsBench':>8}{'Hit %':>9}{'Excess %':>11}  Status")
    for a in agg:
        hit = f"{a['hit_rate']:.1f}" if a["hit_rate"] is not None else "-"
        exc = f"{a['mean_excess']:+.2f}" if a["mean_excess"] is not None else "-"
        flag = "publishable" if a["publishable"] else "sample too small"
        print(f"{a['provider']:<28}{a['evaluated']:>5}{a['evaluated_vs_benchmark']:>8}"
              f"{hit:>9}{exc:>11}  {flag}")
    return 0


def cmd_dashboard(cfg: dict) -> int:
    import subprocess
    return subprocess.call([
        sys.executable, "-m", "streamlit", "run",
        str(Path(__file__).parent / "tasi_agent" / "dashboard.py"),
    ])


def cmd_doctor(cfg: dict) -> int:
    print(f"Version            : {__version__}")
    print(f"Project root       : {cfg['_root']}")
    print(f"Database           : {db_path(cfg)} (exists={db_path(cfg).exists()})")

    print("\nDependencies:")
    for mod, label in [
        ("yaml", "PyYAML"), ("bs4", "BeautifulSoup"), ("lxml", "lxml"),
        ("requests", "requests"), ("pandas", "pandas"), ("openpyxl", "openpyxl"),
        ("fitz", "PyMuPDF"), ("streamlit", "streamlit"), ("playwright", "playwright"),
        ("yfinance", "yfinance"),
    ]:
        try:
            __import__(mod)
            print(f"  {label:<20} ok")
        except ImportError:
            print(f"  {label:<20} MISSING")

    print("\nCollectors:")
    for mod in ("argaam_pages", "euroland_ir", "aljazira", "pdf_inbox",
                "yahoo_prices", "demo"):
        try:
            __import__(f"tasi_agent.collectors.{mod}")
            print(f"  {mod:<20} ok")
        except ImportError as e:
            print(f"  {mod:<20} MISSING ({e})")

    print("\nData inventory:")
    try:
        conn = connect(db_path(cfg))
        for tbl in ("recommendations", "providers", "prices", "index_prices", "splits"):
            try:
                n = conn.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
                print(f"  {tbl:<16} {n:>6} rows")
            except Exception:
                print(f"  {tbl:<16} (table missing)")
    except Exception as exc:
        print(f"  could not open DB: {exc}")

    print("\nConfig summary:")
    print(f"  freshness_days       : {cfg['project']['freshness_days']}")
    print(f"  confirm_threshold    : {cfg['consensus']['confirm_threshold']}")
    print(f"  strong_threshold     : {cfg['consensus']['strong_threshold']}")
    for name in ("argaam", "euroland", "aljazira", "pdf_inbox"):
        c = cfg.get("collectors", {}).get(name, {})
        print(f"  collectors.{name:<12} enabled={c.get('enabled')}")
    print(f"  reporting.auto_open  : {cfg['reporting'].get('auto_open', ['xlsx'])}")
    return 0


def cmd_run_all(cfg: dict) -> int:
    cmd_collect(cfg, None)
    cmd_report(cfg, None)
    return 0


# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="TASI Analyst Consensus Intelligence Agent")
    parser.add_argument("--config", default="config.yaml")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("init")
    sub.add_parser("demo")

    p_collect = sub.add_parser("collect")
    p_collect.add_argument("--source", choices=COLLECTOR_CHOICES)
    p_collect.add_argument("--debug", action="store_true",
                           help="dump fetched HTML to data/debug/")

    p_report = sub.add_parser("report")
    p_report.add_argument("--date")

    sub.add_parser("perf")
    sub.add_parser("dashboard")
    sub.add_parser("doctor")
    sub.add_parser("run-all")

    args = parser.parse_args(argv)
    cfg = load(args.config)

    if args.command == "init":      return cmd_init(cfg)
    if args.command == "demo":      return cmd_demo(cfg)
    if args.command == "collect":   return cmd_collect(cfg, args.source, debug=args.debug)
    if args.command == "report":    return cmd_report(cfg, args.date)
    if args.command == "perf":      return cmd_perf(cfg)
    if args.command == "dashboard": return cmd_dashboard(cfg)
    if args.command == "doctor":    return cmd_doctor(cfg)
    if args.command == "run-all":   return cmd_run_all(cfg)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())